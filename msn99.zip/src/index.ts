let sum = (a: string, b: string) => {
  return a + b;
};
console.log(sum("Hello", "Bye"));
