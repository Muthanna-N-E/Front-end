interface Personal {
  firstName: string;
  lastName: string;
  place: string;
}
interface Contact {
  phoneNumber: number;
  mailId: string;
}

let Details: Personal & Contact = {
  firstName: "Rohan",
  lastName: "Ram",
  place: "Mysore",
  phoneNumber: 9876543210,
  mailId: "abc@gmail.com"
};
console.log(Details);
